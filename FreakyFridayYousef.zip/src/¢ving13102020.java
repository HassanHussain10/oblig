public class øving13102020 {
    public static void main(String)[] args) {








    }







}
